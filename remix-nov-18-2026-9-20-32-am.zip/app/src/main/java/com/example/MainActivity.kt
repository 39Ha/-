package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ai.configureAppCheck
import com.example.ui.screens.DeveloperGuideScreen
import com.example.ui.screens.ForgeStudioScreen
import com.example.ui.screens.ReadyToolsScreen
import com.example.ui.screens.SavedLibraryScreen
import com.example.ui.screens.ToolDetailScreen
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PyTermuxForgeTheme
import com.example.viewmodel.ToolForgeViewModel

private const val ROUTE_FORGE = "forge_studio"
private const val ROUTE_PRESETS = "ready_tools"
private const val ROUTE_LIBRARY = "saved_library"
private const val ROUTE_DEVELOPER = "developer_guide"
private const val ROUTE_DETAIL = "tool_detail/{toolId}"

private data class NavTabItem(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val NAV_TABS = listOf(
    NavTabItem(
        route = ROUTE_FORGE,
        labelRes = R.string.nav_forge,
        selectedIcon = Icons.Filled.AutoAwesome,
        unselectedIcon = Icons.Outlined.AutoAwesome,
        testTag = "nav_tab_forge"
    ),
    NavTabItem(
        route = ROUTE_PRESETS,
        labelRes = R.string.nav_presets,
        selectedIcon = Icons.Filled.Terminal,
        unselectedIcon = Icons.Outlined.Terminal,
        testTag = "nav_tab_presets"
    ),
    NavTabItem(
        route = ROUTE_LIBRARY,
        labelRes = R.string.nav_library,
        selectedIcon = Icons.Filled.Bookmark,
        unselectedIcon = Icons.Outlined.BookmarkBorder,
        testTag = "nav_tab_library"
    ),
    NavTabItem(
        route = ROUTE_DEVELOPER,
        labelRes = R.string.nav_developer,
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person,
        testTag = "nav_tab_developer"
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check with launch intent before UI or ViewModels.
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            PyTermuxForgeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PyTermuxApp()
                }
            }
        }
    }
}

@Composable
fun PyTermuxApp(
    viewModel: ToolForgeViewModel = viewModel()
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val allTools by viewModel.allTools.collectAsStateWithLifecycle()
    val filteredPresets by viewModel.filteredPresets.collectAsStateWithLifecycle()
    val libraryTools by viewModel.libraryTools.collectAsStateWithLifecycle()
    val forgeUiState by viewModel.forgeUiState.collectAsStateWithLifecycle()
    val toolNameInput by viewModel.toolNameInput.collectAsStateWithLifecycle()
    val extraNotesInput by viewModel.extraNotesInput.collectAsStateWithLifecycle()
    val selectedEnvironment by viewModel.selectedEnvironment.collectAsStateWithLifecycle()
    val selectedTier by viewModel.selectedTier.collectAsStateWithLifecycle()
    val presetSearchQuery by viewModel.presetSearchQuery.collectAsStateWithLifecycle()
    val selectedPresetCategory by viewModel.selectedPresetCategory.collectAsStateWithLifecycle()
    val libraryFilter by viewModel.libraryFilter.collectAsStateWithLifecycle()

    val showTopLevelNav = currentRoute in NAV_TABS.map { it.route }

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (showTopLevelNav && !useNavigationRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        NAV_TABS.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(tab.labelRes),
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = EmeraldNeon,
                                    selectedTextColor = EmeraldNeon,
                                    indicatorColor = EmeraldNeon.copy(alpha = 0.16f)
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showTopLevelNav && useNavigationRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        NAV_TABS.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = EmeraldNeon,
                                    selectedTextColor = EmeraldNeon,
                                    indicatorColor = EmeraldNeon.copy(alpha = 0.16f)
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_FORGE,
                    modifier = Modifier
                        .weight(1f)
                        .then(if (showTopLevelNav) Modifier.statusBarsPadding() else Modifier)
                ) {
                    composable(ROUTE_FORGE) {
                        ForgeStudioScreen(
                            toolNameInput = toolNameInput,
                            extraNotesInput = extraNotesInput,
                            selectedEnvironment = selectedEnvironment,
                            selectedTier = selectedTier,
                            forgeUiState = forgeUiState,
                            onToolNameChange = viewModel::updateToolNameInput,
                            onExtraNotesChange = viewModel::updateExtraNotesInput,
                            onEnvironmentSelect = viewModel::selectEnvironment,
                            onTierSelect = viewModel::selectTier,
                            onForgeClick = viewModel::forgeTool,
                            onOpenToolDetail = { tool ->
                                navController.navigate("tool_detail/${tool.id}")
                            }
                        )
                    }

                    composable(ROUTE_PRESETS) {
                        ReadyToolsScreen(
                            presets = filteredPresets,
                            searchQuery = presetSearchQuery,
                            selectedCategory = selectedPresetCategory,
                            onSearchQueryChange = viewModel::updatePresetSearchQuery,
                            onCategorySelect = viewModel::selectPresetCategory,
                            onToolClick = { tool ->
                                navController.navigate("tool_detail/${tool.id}")
                            },
                            onToggleFavorite = viewModel::toggleFavorite
                        )
                    }

                    composable(ROUTE_LIBRARY) {
                        SavedLibraryScreen(
                            tools = libraryTools,
                            activeFilter = libraryFilter,
                            onFilterSelect = viewModel::selectLibraryFilter,
                            onToolClick = { tool ->
                                navController.navigate("tool_detail/${tool.id}")
                            },
                            onToggleFavorite = viewModel::toggleFavorite,
                            onDeleteTool = viewModel::deleteTool,
                            onNavigateToForge = { navigateToTab(ROUTE_FORGE) }
                        )
                    }

                    composable(ROUTE_DEVELOPER) {
                        DeveloperGuideScreen(allTools = allTools)
                    }

                    composable(
                        route = ROUTE_DETAIL,
                        arguments = listOf(navArgument("toolId") { type = NavType.LongType })
                    ) { entry ->
                        val toolId = entry.arguments?.getLong("toolId") ?: 0L
                        val tool by viewModel.observeToolById(toolId)
                            .collectAsStateWithLifecycle(initialValue = null)

                        ToolDetailScreen(
                            tool = tool,
                            onBack = { navController.popBackStack() },
                            onToggleFavorite = viewModel::toggleFavorite,
                            onCustomizeWithAi = { selected ->
                                viewModel.prefillFromPreset(selected)
                                navigateToTab(ROUTE_FORGE)
                            }
                        )
                    }
                }
            }
        }
    }
}
