package com.example.data

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "ToolRepository"

class ToolRepository(private val toolDao: ToolDao) {

    val allTools: Flow<List<ToolEntity>> = toolDao.observeAllTools()

    fun observeToolById(toolId: Long): Flow<ToolEntity?> = toolDao.observeToolById(toolId)

    suspend fun ensurePresetsSeeded() {
        if (toolDao.countPresets() == 0) {
            toolDao.insertAll(ToolPresets.getInitialPresets())
        }
    }

    suspend fun toggleFavorite(toolId: Long, isFavorite: Boolean) {
        toolDao.updateFavorite(toolId, isFavorite)
    }

    suspend fun deleteTool(toolId: Long) {
        toolDao.deleteToolById(toolId)
    }

    private val toolSchema = Schema.obj(
        properties = mapOf(
            "toolName" to Schema.string(description = "Clean Arabic display title for the tool"),
            "fileName" to Schema.string(description = "Safe lowercase filename ending with .py or .sh"),
            "category" to Schema.enumeration(
                values = listOf("تجهيز وتنزيل", "بايثون", "تيرمكس", "شبكات وأنظمة"),
                description = "Tool category in Arabic"
            ),
            "summary" to Schema.string(description = "Clear Arabic explanation of what the tool does"),
            "setupCommands" to Schema.array(
                items = Schema.string(),
                description = "Exact Termux setup commands such as pkg install or pip install"
            ),
            "runCommand" to Schema.string(description = "Exact command to run the script in Termux"),
            "sourceCode" to Schema.string(description = "Complete, safe, runnable Python 3 or Termux Bash script"),
            "usageNotes" to Schema.string(description = "Helpful Arabic usage notes and tips")
        )
    )

    private val generativeModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = toolSchema
                temperature = 0.45f
            }
        )
    }

    suspend fun generateCustomTool(
        requestedName: String,
        environment: String,
        tier: String,
        extraNotes: String
    ): Result<ToolEntity> {
        val prompt = buildString {
            appendLine("أنت مهندس برمجيات خبير في Python 3 و Termux على نظام أندرويد، وتبني أدوات احترافية لصالح استوديو المطور حسين عليشدهان (Hussein Alishadhan).")
            appendLine("المطلوب: أنشئ أداة حقيقية وعملية وآمنة بناءً على الاسم والوصف التالي:")
            appendLine("- اسم الأداة المطلوبة: $requestedName")
            appendLine("- البيئة المستهدفة: $environment")
            appendLine("- المستوى / النوع: $tier")
            if (extraNotes.isNotBlank()) {
                appendLine("- متطلبات إضافية: $extraNotes")
            }
            appendLine()
            appendLine("الشروط الإلزامية:")
            appendLine("1. يجب أن يكون الكود حقيقياً وقابلاً للتشغيل مباشرة في Termux أو Python 3 بدون أخطاء وبدون أجزاء ناقصة أو TODO.")
            appendLine("2. يجب أن يبدأ الكود بتعليق يتضمن اسم الأداة واسم المطور: '# المطور: حسين عليشدهان | Hussein Alishadhan'.")
            appendLine("3. التزم بالسلامة البرمجية: أنشئ فقط أدوات برمجية مفيدة وآمنة (إدارة ملفات، تثبيت حزم، تشخيص شبكات مشروع، واجهات CLI، مراقبة نظام، نسخ احتياطي، تحويل بيانات، أتمتة). لا تنشئ أي برمجيات خبيثة أو هجومية.")
            appendLine("4. أضف أوامر التثبيت الدقيقة في Termux (مثل pkg install python -y و pip install ...) في setupCommands.")
            appendLine("5. استخدم واجهة طرفية جميلة ومنظمة باللغة العربية أو الإنجليزية الواضحة داخل السكربت.")
        }

        return try {
            val response = withTimeout(60_000L) {
                generativeModel.generateContent(prompt)
            }
            val rawJson = response.text
                ?: return Result.failure(IllegalStateException("لم يُرجع النموذج أي بيانات. حاول مرة أخرى."))

            val json = JSONObject(rawJson)
            val setupArray = json.optJSONArray("setupCommands")
            val setupList = if (setupArray != null) {
                (0 until setupArray.length()).map { setupArray.getString(it) }
            } else {
                listOf("pkg install python -y")
            }

            val generatedTool = ToolEntity(
                name = json.optString("toolName").ifBlank { requestedName },
                fileName = json.optString("fileName").ifBlank {
                    if (environment.contains("Bash")) "custom_tool.sh" else "custom_tool.py"
                },
                environment = environment,
                category = json.optString("category").ifBlank { "بايثون" },
                tier = tier,
                summary = json.optString("summary").ifBlank { "أداة مخصصة تم توليدها بواسطة صانع بايثون وتيرمكس." },
                setupCommands = setupList.joinToString("\n"),
                runCommand = json.optString("runCommand").ifBlank { "python custom_tool.py" },
                sourceCode = json.optString("sourceCode"),
                usageNotes = json.optString("usageNotes").ifBlank { "انسخ الأوامر وشغّلها في تطبيق Termux." },
                isPreset = false,
                isFavorite = false,
                createdAt = System.currentTimeMillis()
            )

            if (generatedTool.sourceCode.isBlank()) {
                return Result.failure(IllegalStateException("تعذر توليد الكود البرمجي للأداة. حاول صياغة الاسم بشكل أوضح."))
            }

            val insertedId = toolDao.insertTool(generatedTool)
            Result.success(generatedTool.copy(id = insertedId))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI generation timed out", e)
            Result.failure(IllegalStateException("انتهت مهلة التوليد (60 ثانية). تحقق من الاتصال وحاول مجدداً."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI generation failed", e)
            Result.failure(IllegalStateException(e.localizedMessage ?: "حدث خطأ أثناء توليد الأداة."))
        }
    }
}
