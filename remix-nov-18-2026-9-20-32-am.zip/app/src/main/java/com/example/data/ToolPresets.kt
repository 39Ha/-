package com.example.data

object ToolPresets {
    fun getInitialPresets(): List<ToolEntity> {
        val baseTime = System.currentTimeMillis()
        return listOf(
            ToolEntity(
                name = "التجهيز الشامل لتيرمكس وبايثون",
                fileName = "termux_mega_setup.sh",
                environment = "Termux Bash",
                category = "تجهيز وتنزيل",
                tier = "تجهيز شامل",
                summary = "سكربت جاهز لتحديث تيرمكس وتنزيل الحزم الأساسية (Python, Git, Curl, Wget, Nano, OpenSSH) وتهيئة بيئة البرمجة بنقرة واحدة.",
                setupCommands = "pkg update -y && pkg upgrade -y\ntermux-setup-storage",
                runCommand = "bash termux_mega_setup.sh",
                sourceCode = """
#!/data/data/com.termux/files/usr/bin/bash
# ==========================================
# الأداة: التجهيز الشامل لتيرمكس وبايثون
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

echo -e "\033[1;32m[+] بدء تحديث مستودعات Termux...\033[0m"
pkg update -y && pkg upgrade -y

PACKAGES=(python python-pip git curl wget nano zip unzip openssh clang)
for pkg_name in "${'$'}{PACKAGES[@]}"; do
    echo -e "\033[1;36m[*] جاري تنزيل وتثبيت: ${'$'}pkg_name\033[0m"
    pkg install -y "${'$'}pkg_name"
done

echo -e "\033[1;33m[*] تحديث مدير حزم بايثون pip...\033[0m"
python -m pip install --upgrade pip

echo -e "\033[1;32m[✓] تم تجهيز Termux بنجاح بواسطة أداة المطور حسين عليشدهان!\033[0m"
                """.trimIndent(),
                usageNotes = "يُنصح بتشغيل هذا السكربت عند تثبيت Termux لأول مرة لتهيئة جميع الأدوات الأساسية.",
                isPreset = true,
                createdAt = baseTime - 10_000
            ),
            ToolEntity(
                name = "مُثبّت ومُرتّب حزم بايثون السريع",
                fileName = "pip_rank_installer.py",
                environment = "Python + Termux",
                category = "تجهيز وتنزيل",
                tier = "جاهز للتشغيل",
                summary = "أداة بايثون تفاعلية لتنزيل وترتيب أشهر مكتبات بايثون البرمجية (Rich, Requests, Colorama, Tqdm, Flask) مع عرض شريط التقدم.",
                setupCommands = "pkg install python -y\npip install --upgrade pip",
                runCommand = "python pip_rank_installer.py",
                sourceCode = """
#!/usr/bin/env python3
# ==========================================
# الأداة: مثبت ومرتب حزم بايثون السريع
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

import subprocess
import sys

LIBRARIES = [
    ("requests", "إرسال طلبات HTTP والاتصال بالشبكة"),
    ("rich", "تنسيق الجداول والألوان في الطرفية"),
    ("colorama", "تلوين مخرجات النصوص في الترمينال"),
    ("tqdm", "عرض أشرطة التقدم للعمليات"),
    ("beautifulsoup4", "تحليل وقراءة صفحات الويب"),
    ("flask", "بناء خوادم ويب و API خفيفة")
]

def install_package(pkg_name: str) -> bool:
    print(f"\n[+] جاري تنزيل وتثبيت: {pkg_name} ...")
    result = subprocess.run([sys.executable, "-m", "pip", "install", pkg_name])
    return result.returncode == 0

def main():
    print("=" * 48)
    print("  صانع ومثبت حزم بايثون | المطور: حسين عليشدهان")
    print("=" * 48)
    for idx, (lib, desc) in enumerate(LIBRARIES, start=1):
        print(f"[{idx}] {lib:<16} - {desc}")
    print("[0] تثبيت جميع المكتبات دفعة واحدة")

    choice = input("\nاختر رقم المكتبة أو 0 للكل: ").strip()
    if choice == "0":
        for lib, _ in LIBRARIES:
            install_package(lib)
    elif choice.isdigit() and 1 <= int(choice) <= len(LIBRARIES):
        lib = LIBRARIES[int(choice) - 1][0]
        ok = install_package(lib)
        print("[✓] تم التثبيت بنجاح" if ok else "[!] تعذر التثبيت")
    else:
        print("[!] اختيار غير صالح")

if __name__ == "__main__":
    main()
                """.trimIndent(),
                usageNotes = "يعمل مباشرة على بايثون 3 بدون الحاجة لمكتبات خارجية قبل التشغيل.",
                isPreset = true,
                createdAt = baseTime - 20_000
            ),
            ToolEntity(
                name = "أداة فحص الشبكة وسرعة الاستجابة",
                fileName = "net_ping_inspector.py",
                environment = "Python CLI",
                category = "شبكات وأنظمة",
                tier = "جاهز للتشغيل",
                summary = "أداة تشخيص شبكة في بايثون تفحص عنوان IP المحلي، دقة الـ DNS، وزمن الاستجابة بالملي ثانية لأي نطاق.",
                setupCommands = "pkg install python -y",
                runCommand = "python net_ping_inspector.py",
                sourceCode = """
#!/usr/bin/env python3
# ==========================================
# الأداة: فاحص الشبكة وزمن الاستجابة
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

import socket
import time
import urllib.request

def check_host(host: str, port: int = 443) -> None:
    try:
        ip = socket.gethostbyname(host)
        start = time.perf_counter()
        with socket.create_connection((ip, port), timeout=5):
            elapsed_ms = (time.perf_counter() - start) * 1000
        print(f"[✓] {host} ({ip}:{port}) -> استجابة: {elapsed_ms:.1f} ms")
    except Exception as exc:
        print(f"[!] تعذر الاتصال بـ {host}: {exc}")

def get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "غير متصل"

def main():
    print("--- فاحص الشبكة | المطور: حسين عليشدهان ---")
    print(f"عنوان الشبكة المحلي (Local IP): {get_local_ip()}")
    target = input("أدخل اسم النطاق للفحص (مثال google.com): ").strip() or "google.com"
    check_host(target, 443)
    try:
        start = time.perf_counter()
        with urllib.request.urlopen(f"https://{target}", timeout=6) as resp:
            ms = (time.perf_counter() - start) * 1000
            print(f"[✓] حالة HTTP: {resp.status} | زمن التحميل: {ms:.1f} ms")
    except Exception as exc:
        print(f"[!] ملاحظة HTTP: {exc}")

if __name__ == "__main__":
    main()
                """.trimIndent(),
                usageNotes = "يعتمد على مكتبات بايثون القياسية فقط (socket, time, urllib).",
                isPreset = true,
                createdAt = baseTime - 30_000
            ),
            ToolEntity(
                name = "منظم الملفات الذكي في تيرمكس",
                fileName = "smart_file_organizer.py",
                environment = "Python + Termux",
                category = "تيرمكس",
                tier = "جاهز للتشغيل",
                summary = "يرتب الملفات المبعثرة في مجلد محدد إلى مجلدات مصنفة تلقائياً (صور، مستندات، سكربتات، أرشيف، وسائط).",
                setupCommands = "pkg install python -y\ntermux-setup-storage",
                runCommand = "python smart_file_organizer.py",
                sourceCode = """
#!/usr/bin/env python3
# ==========================================
# الأداة: منظم الملفات الذكي
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

import os
import shutil
from pathlib import Path

CATEGORIES = {
    "Images": {".png", ".jpg", ".jpeg", ".webp", ".gif"},
    "Documents": {".pdf", ".txt", ".docx", ".md", ".csv"},
    "Scripts": {".py", ".sh", ".js", ".json"},
    "Archives": {".zip", ".tar", ".gz", ".rar"},
    "Media": {".mp3", ".mp4", ".mkv", ".wav"}
}

def organize_folder(target_dir: str) -> None:
    root = Path(target_dir).expanduser()
    if not root.is_dir():
        print("[!] المسار غير موجود.")
        return

    moved_count = 0
    for item in root.iterdir():
        if item.is_file():
            ext = item.suffix.lower()
            dest_name = "Others"
            for category, extensions in CATEGORIES.items():
                if ext in extensions:
                    dest_name = category
                    break
            dest_dir = root / dest_name
            dest_dir.mkdir(exist_ok=True)
            shutil.move(str(item), str(dest_dir / item.name))
            moved_count += 1
            print(f"[+] نقل {item.name} -> {dest_name}/")

    print(f"\n[✓] تم تنظيم {moved_count} ملف بنجاح!")

if __name__ == "__main__":
    print("--- منظم الملفات | المطور: حسين عليشدهان ---")
    path = input("أدخل مسار المجلد (اتركه فارغاً للمجلد الحالي): ").strip() or "."
    organize_folder(path)
                """.trimIndent(),
                usageNotes = "لتنظيم مجلد التنزيلات في الهاتف أدخل المسار: ~/storage/downloads",
                isPreset = true,
                createdAt = baseTime - 40_000
            ),
            ToolEntity(
                name = "مراقب موارد الجهاز والذاكرة",
                fileName = "system_monitor.py",
                environment = "Python + Termux",
                category = "شبكات وأنظمة",
                tier = "احترافي",
                summary = "يعرض إحصائيات المعالج، الذاكرة العشوائية، مساحة التخزين المتاحة، وإصدار بايثون والنظام داخل تيرمكس.",
                setupCommands = "pkg install python -y",
                runCommand = "python system_monitor.py",
                sourceCode = """
#!/usr/bin/env python3
# ==========================================
# الأداة: مراقب النظام والموارد
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

import os
import platform
import shutil

def read_meminfo():
    info = {}
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as f:
            for line in f:
                parts = line.split(":")
                if len(parts) == 2:
                    key = parts[0].strip()
                    val = parts[1].strip().split()[0]
                    info[key] = int(val) // 1024
    except Exception:
        pass
    return info

def main():
    print("=" * 46)
    print("  مراقب النظام | المطور: حسين عليشدهان")
    print("=" * 46)
    print(f"النظام      : {platform.system()} {platform.release()}")
    print(f"المعمارية   : {platform.machine()}")
    print(f"إصدار بايثون: {platform.python_version()}")
    print(f"عدد الأنوية : {os.cpu_count()}")

    total, used, free = shutil.disk_usage("/")
    gb = 1024 ** 3
    print(f"التخزين     : مستخدم {used / gb:.1f} GB / متاح {free / gb:.1f} GB من {total / gb:.1f} GB")

    mem = read_meminfo()
    if "MemTotal" in mem and "MemAvailable" in mem:
        print(f"الذاكرة RAM : متاح {mem['MemAvailable']} MB / الإجمالي {mem['MemTotal']} MB")

if __name__ == "__main__":
    main()
                """.trimIndent(),
                usageNotes = "يعرض معلومات فورية عن الذاكرة والتخزين في بيئة Android/Termux.",
                isPreset = true,
                createdAt = baseTime - 50_000
            ),
            ToolEntity(
                name = "أداة فحص الروابط ورؤوس HTTP",
                fileName = "http_header_check.py",
                environment = "Python CLI",
                category = "بايثون",
                tier = "احترافي",
                summary = "تفحص استجابة المواقع، رمز الحالة، رؤوس الأمان، وتحويلات الروابط بشكل سريع ومنظم.",
                setupCommands = "pkg install python -y\npip install requests",
                runCommand = "python http_header_check.py",
                sourceCode = """
#!/usr/bin/env python3
# ==========================================
# الأداة: فاحص الروابط ورؤوس HTTP
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

import requests

def inspect_url(url: str) -> None:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    try:
        resp = requests.get(url, timeout=10, allow_redirects=True)
        print(f"\n[✓] الرابط النهائي : {resp.url}")
        print(f"[✓] رمز الحالة    : {resp.status_code}")
        print(f"[✓] زمن الاستجابة : {resp.elapsed.total_seconds():.2f} ثانية")
        print("\n--- أهم رؤوس الاستجابة ---")
        for k, v in list(resp.headers.items())[:12]:
            print(f"  {k}: {v}")
    except requests.RequestException as err:
        print(f"[!] خطأ في الاتصال: {err}")

if __name__ == "__main__":
    print("--- فاحص HTTP | المطور: حسين عليشدهان ---")
    target = input("أدخل الرابط للفحص: ").strip()
    if target:
        inspect_url(target)
                """.trimIndent(),
                usageNotes = "مفيد للمطورين للتحقق من عمل واجهات API وشهادات HTTPS.",
                isPreset = true,
                createdAt = baseTime - 60_000
            ),
            ToolEntity(
                name = "مُشفّر النصوص وبصمة SHA-256",
                fileName = "text_hash_cipher.py",
                environment = "Python CLI",
                category = "بايثون",
                tier = "جاهز للتشغيل",
                summary = "أداة بايثون لتحويل النصوص إلى Base64 وفك ترميزها، وتوليد بصمات التحقق SHA-256 و MD5 للتحقق من سلامة الملفات.",
                setupCommands = "pkg install python -y",
                runCommand = "python text_hash_cipher.py",
                sourceCode = """
#!/usr/bin/env python3
# ==========================================
# الأداة: ترميز النصوص وبصمات التحقق
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

import base64
import hashlib

def main():
    print("--- أداة الترميز والتحقق | المطور: حسين عليشدهان ---")
    print("[1] ترميز Base64")
    print("[2] فك ترميز Base64")
    print("[3] حساب بصمة SHA-256 لنص")
    choice = input("اختر العملية: ").strip()
    text = input("أدخل النص: ")

    if choice == "1":
        encoded = base64.b64encode(text.encode("utf-8")).decode("utf-8")
        print(f"النتيجة: {encoded}")
    elif choice == "2":
        try:
            decoded = base64.b64decode(text.encode("utf-8")).decode("utf-8")
            print(f"النص الأصلي: {decoded}")
        except Exception:
            print("[!] نص Base64 غير صالح.")
    elif choice == "3":
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        print(f"SHA-256: {digest}")
    else:
        print("[!] خيار غير صحيح.")

if __name__ == "__main__":
    main()
                """.trimIndent(),
                usageNotes = "يعمل فوراً بالاعتماد على مكتبات بايثون القياسية.",
                isPreset = true,
                createdAt = baseTime - 70_000
            ),
            ToolEntity(
                name = "مُساعد مستودعات Git السريع",
                fileName = "git_quick_sync.sh",
                environment = "Termux Bash",
                category = "تيرمكس",
                tier = "جاهز للتشغيل",
                summary = "أداة تيرمكس سريعة لاستنساخ مستودعات GitHub أو تحديث المشروع المحلي ورفع التعديلات بأوامر مبسطة.",
                setupCommands = "pkg install git -y",
                runCommand = "bash git_quick_sync.sh",
                sourceCode = """
#!/data/data/com.termux/files/usr/bin/bash
# ==========================================
# الأداة: مساعد Git السريع
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

echo "=== مساعد Git السريع | حسين عليشدهان ==="
echo "1) استنساخ مستودع (git clone)"
echo "2) تحديث المستودع الحالي (git pull)"
echo "3) عرض حالة الملفات (git status)"
read -p "اختر رقماً: " opt

case "${'$'}opt" in
  1)
    read -p "أدخل رابط المستودع: " repo_url
    git clone "${'$'}repo_url"
    ;;
  2)
    git pull
    ;;
  3)
    git status
    ;;
  *)
    echo "خيار غير معروف"
    ;;
esac
                """.trimIndent(),
                usageNotes = "تأكد من تثبيت Git مسبقاً عبر pkg install git -y.",
                isPreset = true,
                createdAt = baseTime - 80_000
            ),
            ToolEntity(
                name = "صانع رموز QR داخل الطرفية",
                fileName = "terminal_qr_maker.py",
                environment = "Python + Termux",
                category = "بايثون",
                tier = "جاهز للتشغيل",
                summary = "يحول أي رابط أو نص إلى رمز QR واضح يُعرض مباشرة داخل شاشة Termux مع خيار حفظه كصورة.",
                setupCommands = "pkg install python -y\npip install qrcode",
                runCommand = "python terminal_qr_maker.py",
                sourceCode = """
#!/usr/bin/env python3
# ==========================================
# الأداة: صانع QR في التيرمكس
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

import qrcode

def main():
    print("--- صانع QR | المطور: حسين عليشدهان ---")
    data = input("أدخل النص أو الرابط: ").strip()
    if not data:
        print("[!] لا يمكن إنشاء رمز من نص فارغ.")
        return
    qr = qrcode.QRCode(border=1)
    qr.add_data(data)
    qr.make(fit=True)
    qr.print_ascii(invert=True)

if __name__ == "__main__":
    main()
                """.trimIndent(),
                usageNotes = "امسح الرمز الظاهر في التيرمكس مباشرة بكاميرا أي هاتف.",
                isPreset = true,
                createdAt = baseTime - 90_000
            ),
            ToolEntity(
                name = "أداة النسخ الاحتياطي لمشاريع تيرمكس",
                fileName = "termux_backup.sh",
                environment = "Termux Bash",
                category = "تجهيز وتنزيل",
                tier = "تجهيز شامل",
                summary = "تضغط جميع سكربتاتك وملفات مشاريعك في المجلد الرئيسي إلى نسخة احتياطية مؤرخة بصيغة tar.gz.",
                setupCommands = "pkg install tar gzip -y\ntermux-setup-storage",
                runCommand = "bash termux_backup.sh",
                sourceCode = """
#!/data/data/com.termux/files/usr/bin/bash
# ==========================================
# الأداة: النسخ الاحتياطي لمشاريع تيرمكس
# المطور: حسين عليشدهان | Hussein Alishadhan
# ==========================================

BACKUP_DIR="${'$'}HOME/storage/downloads/TermuxBackups"
mkdir -p "${'$'}BACKUP_DIR"
STAMP=$(date +"%Y%m%d_%H%M%S")
OUT_FILE="${'$'}BACKUP_DIR/termux_scripts_${'$'}STAMP.tar.gz"

echo "[*] جاري إنشاء نسخة احتياطية للملفات..."
tar -czf "${'$'}OUT_FILE" -C "${'$'}HOME" --exclude="storage" .
echo "[✓] تم حفظ النسخة الاحتياطية في: ${'$'}OUT_FILE"
                """.trimIndent(),
                usageNotes = "يحفظ النسخة تلقائياً داخل مجلد Downloads/TermuxBackups في الهاتف.",
                isPreset = true,
                createdAt = baseTime - 100_000
            )
        )
    }
}
