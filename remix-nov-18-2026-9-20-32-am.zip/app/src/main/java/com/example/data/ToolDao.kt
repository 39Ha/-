package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ToolDao {
    @Query("SELECT * FROM tools ORDER BY isPreset ASC, createdAt DESC")
    fun observeAllTools(): Flow<List<ToolEntity>>

    @Query("SELECT * FROM tools WHERE id = :toolId")
    fun observeToolById(toolId: Long): Flow<ToolEntity?>

    @Query("SELECT COUNT(*) FROM tools WHERE isPreset = 1")
    suspend fun countPresets(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTool(tool: ToolEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tools: List<ToolEntity>)

    @Query("UPDATE tools SET isFavorite = :isFavorite WHERE id = :toolId")
    suspend fun updateFavorite(toolId: Long, isFavorite: Boolean)

    @Query("DELETE FROM tools WHERE id = :toolId")
    suspend fun deleteToolById(toolId: Long)
}
