package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tools")
data class ToolEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val fileName: String,
    val environment: String,
    val category: String,
    val tier: String,
    val summary: String,
    val setupCommands: String,
    val runCommand: String,
    val sourceCode: String,
    val usageNotes: String,
    val isPreset: Boolean = false,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
