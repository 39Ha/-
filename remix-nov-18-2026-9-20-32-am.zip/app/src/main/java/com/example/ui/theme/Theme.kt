package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkTerminalScheme = darkColorScheme(
    primary = EmeraldNeon,
    onPrimary = TerminalObsidian,
    primaryContainer = EmeraldDeep,
    onPrimaryContainer = EmeraldSoft,
    secondary = PythonAmber,
    onSecondary = TerminalObsidian,
    secondaryContainer = PythonAmberDeep,
    onSecondaryContainer = PythonAmberSoft,
    tertiary = CyberCyan,
    onTertiary = TerminalObsidian,
    tertiaryContainer = CyberCyanDeep,
    onTertiaryContainer = CyberCyanSoft,
    background = TerminalObsidian,
    onBackground = TextPrimaryDark,
    surface = TerminalSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = TerminalSurfaceElevated,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerLow = TerminalSurface,
    surfaceContainer = TerminalSurfaceElevated,
    surfaceContainerHigh = TerminalSurfaceHighest,
    outline = BorderSubtleDark,
    outlineVariant = BorderSubtleDark,
    error = ErrorCoral,
    onError = Color.White,
    errorContainer = ErrorContainerDark,
    onErrorContainer = Color(0xFFFFD6DD)
)

private val LightTerminalScheme = lightColorScheme(
    primary = EmeraldPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD0F7E3),
    onPrimaryContainer = Color(0xFF002112),
    secondary = AmberSecondaryLight,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE5C2),
    onSecondaryContainer = Color(0xFF2D1900),
    tertiary = CyanTertiaryLight,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFD6EEFF),
    onTertiaryContainer = Color(0xFF001E30),
    background = LightBg,
    onBackground = Color(0xFF0F172A),
    surface = LightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1)
)

@Composable
fun PyTermuxForgeTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkTerminalScheme else LightTerminalScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
