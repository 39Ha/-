package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ToolEntity
import com.example.ui.components.TerminalCommandBox
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PythonAmber

@Composable
fun DeveloperGuideScreen(
    allTools: List<ToolEntity>,
    modifier: Modifier = Modifier
) {
    val presetCount = allTools.count { it.isPreset }
    val customCount = allTools.count { !it.isPreset }
    val favoriteCount = allTools.count { it.isFavorite }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = 680.dp)) {
            // Developer Spotlight Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                ),
                border = BorderStroke(1.dp, EmeraldNeon.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.img_dev_emblem),
                            contentDescription = stringResource(R.string.cd_dev_emblem),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = stringResource(R.string.developer_name),
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = null,
                                    tint = EmeraldNeon,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "مطور أدوات بايثون وتيرمكس",
                                style = MaterialTheme.typography.titleSmall,
                                color = PythonAmber
                            )
                            Text(
                                text = "Hussein Alishadhan Studio",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "منصة متكاملة لصناعة أدوات بايثون وتيرمكس الجاهزة والمخصصة. اكتب اسم أي أداة تريدها لتحصل فوراً على الكود الكامل مع أوامر التثبيت والتشغيل المباشر في Termux.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatBox(
                            value = presetCount.toString(),
                            label = "أداة جاهزة",
                            accent = EmeraldNeon,
                            modifier = Modifier.weight(1f)
                        )
                        StatBox(
                            value = customCount.toString(),
                            label = "من صنعك",
                            accent = CyberCyan,
                            modifier = Modifier.weight(1f)
                        )
                        StatBox(
                            value = favoriteCount.toString(),
                            label = "المفضلة",
                            accent = PythonAmber,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Step-by-step Termux Guide
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = null,
                    tint = PythonAmber,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "دليل التشغيل السريع في Termux",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            GuideStepCard(
                step = "1",
                title = "تحديث تيرمكس وتثبيت بايثون",
                description = "شغّل هذا الأمر أول مرة داخل Termux لتحديث الحزم وتثبيت Python و Git:"
            )
            Spacer(modifier = Modifier.height(8.dp))
            TerminalCommandBox(
                title = "أمر التجهيز الأساسي",
                command = "pkg update -y && pkg upgrade -y && pkg install python git curl -y",
                accentColor = EmeraldNeon,
                testTagPrefix = "guide_step1"
            )

            Spacer(modifier = Modifier.height(14.dp))

            GuideStepCard(
                step = "2",
                title = "منح صلاحية التخزين (اختياري)",
                description = "إذا أردت أن تصل أدواتك إلى مجلد التنزيلات والملفات في الهاتف:"
            )
            Spacer(modifier = Modifier.height(8.dp))
            TerminalCommandBox(
                title = "صلاحية ملفات الهاتف",
                command = "termux-setup-storage",
                accentColor = CyberCyan,
                testTagPrefix = "guide_step2"
            )

            Spacer(modifier = Modifier.height(14.dp))

            GuideStepCard(
                step = "3",
                title = "تشغيل أي أداة بضغطة واحدة",
                description = "افتح أي أداة داخل التطبيق واضغط «نسخ أمر التثبيت والتشغيل المباشر في Termux» ثم الصقه في شاشة Termux واضغط Enter!"
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun StatBox(
    value: String,
    label: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = accent.copy(alpha = 0.1f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = accent
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun GuideStepCard(
    step: String,
    title: String,
    description: String
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                shape = CircleShape,
                color = EmeraldNeon.copy(alpha = 0.18f),
                modifier = Modifier.size(32.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = step,
                        style = MaterialTheme.typography.titleSmall,
                        color = EmeraldNeon
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
