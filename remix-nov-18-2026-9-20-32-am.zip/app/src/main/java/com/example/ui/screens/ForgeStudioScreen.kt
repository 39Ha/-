package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ToolEntity
import com.example.ui.components.TerminalCodeViewer
import com.example.ui.components.TerminalCommandBox
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.PythonAmber
import com.example.ui.theme.TerminalObsidian
import com.example.viewmodel.ForgeUiState

private val QUICK_IDEAS = listOf(
    "أداة تنزيل وتثبيت مكتبات بايثون تلقائياً",
    "أداة فحص سرعة الإنترنت والمنافذ المفتوحة",
    "أداة تنظيم وترتيب ملفات الهاتف في تيرمكس",
    "أداة مراقبة المعالج والذاكرة في Termux",
    "أداة تشفير النصوص والملفات بصيغة SHA256",
    "أداة نسخ احتياطي لمشاريع بايثون"
)

private val ENVIRONMENTS = listOf("Python + Termux", "Python CLI", "Termux Bash")
private val TIERS = listOf("تجهيز وتنزيل", "جاهز للتشغيل", "احترافي")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ForgeStudioScreen(
    toolNameInput: String,
    extraNotesInput: String,
    selectedEnvironment: String,
    selectedTier: String,
    forgeUiState: ForgeUiState,
    onToolNameChange: (String) -> Unit,
    onExtraNotesChange: (String) -> Unit,
    onEnvironmentSelect: (String) -> Unit,
    onTierSelect: (String) -> Unit,
    onForgeClick: () -> Unit,
    onOpenToolDetail: (ToolEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = 680.dp)) {
            // Hero Banner Card with Developer Attribution
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(176.dp)
                    .clip(RoundedCornerShape(24.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_terminal_hero),
                    contentDescription = stringResource(R.string.cd_hero_banner),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    TerminalObsidian.copy(alpha = 0.35f),
                                    TerminalObsidian.copy(alpha = 0.92f)
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = EmeraldNeon.copy(alpha = 0.16f),
                        border = BorderStroke(1.dp, EmeraldNeon.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = EmeraldNeon,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.developer_title),
                                style = MaterialTheme.typography.labelMedium,
                                color = EmeraldNeon
                            )
                        }
                    }

                    Column {
                        Text(
                            text = "استوديو صناعة أدوات بايثون وتيرمكس",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.forge_hero_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Builder Card
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = null,
                            tint = EmeraldNeon,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اكتب اسم الأداة وسيتم برمجتها فوراً",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = toolNameInput,
                        onValueChange = onToolNameChange,
                        label = { Text(stringResource(R.string.forge_input_label)) },
                        placeholder = { Text(stringResource(R.string.forge_input_placeholder)) },
                        singleLine = false,
                        maxLines = 3,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldNeon,
                            focusedLabelColor = EmeraldNeon,
                            cursorColor = EmeraldNeon
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tool_name_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = extraNotesInput,
                        onValueChange = onExtraNotesChange,
                        label = { Text(stringResource(R.string.forge_notes_label)) },
                        placeholder = { Text(stringResource(R.string.forge_notes_placeholder)) },
                        singleLine = false,
                        maxLines = 2,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            focusedLabelColor = CyberCyan,
                            cursorColor = CyberCyan
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tool_notes_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "البيئة المستهدفة",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ENVIRONMENTS.forEach { env ->
                            val selected = selectedEnvironment == env
                            FilterChip(
                                selected = selected,
                                onClick = { onEnvironmentSelect(env) },
                                label = { Text(env) },
                                leadingIcon = if (selected) {
                                    {
                                        Icon(
                                            imageVector = Icons.Default.Code,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                } else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldNeon.copy(alpha = 0.2f),
                                    selectedLabelColor = EmeraldNeon,
                                    selectedLeadingIconColor = EmeraldNeon
                                ),
                                modifier = Modifier.testTag("env_chip_${env.replace(" ", "_")}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "نوع التجهيز / المستوى",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TIERS.forEach { tier ->
                            val selected = selectedTier == tier
                            FilterChip(
                                selected = selected,
                                onClick = { onTierSelect(tier) },
                                label = { Text(tier) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PythonAmber.copy(alpha = 0.2f),
                                    selectedLabelColor = PythonAmber
                                ),
                                modifier = Modifier.testTag("tier_chip_${tier.replace(" ", "_")}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onForgeClick,
                        enabled = forgeUiState !is ForgeUiState.Loading,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldNeon,
                            contentColor = TerminalObsidian
                        ),
                        contentPadding = PaddingValues(vertical = 14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 52.dp)
                            .testTag("forge_submit_button")
                    ) {
                        if (forgeUiState is ForgeUiState.Loading) {
                            CircularProgressIndicator(
                                color = TerminalObsidian,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = stringResource(R.string.forge_loading),
                                style = MaterialTheme.typography.labelLarge
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.forge_button),
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Suggestion Chips
            Text(
                text = "اقتراحات سريعة لصنع أدوات جاهزة",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QUICK_IDEAS.forEachIndexed { idx, idea ->
                    AssistChip(
                        onClick = { onToolNameChange(idea) },
                        label = { Text(idea, style = MaterialTheme.typography.bodySmall) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = PythonAmber,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        ),
                        modifier = Modifier.testTag("quick_idea_chip_$idx")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Error Feedback
            AnimatedVisibility(
                visible = forgeUiState is ForgeUiState.Error,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                if (forgeUiState is ForgeUiState.Error) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("forge_error_card")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = forgeUiState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }

            // Live Generated Result Preview
            AnimatedVisibility(
                visible = forgeUiState is ForgeUiState.Success,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                if (forgeUiState is ForgeUiState.Success) {
                    val tool = forgeUiState.tool
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("forge_success_result")
                    ) {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainer
                            ),
                            border = BorderStroke(1.2.dp, EmeraldNeon.copy(alpha = 0.6f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = EmeraldNeon
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "تمت صناعة الأداة وحفظها",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = EmeraldNeon
                                        )
                                    }
                                    Button(
                                        onClick = { onOpenToolDetail(tool) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = CyberCyan,
                                            contentColor = TerminalObsidian
                                        ),
                                        modifier = Modifier
                                            .heightIn(min = 48.dp)
                                            .testTag("open_generated_tool_detail")
                                    ) {
                                        Text("فتح التفاصيل")
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = tool.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = tool.summary,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                TerminalCommandBox(
                                    title = "أوامر التثبيت والتجهيز في Termux",
                                    command = tool.setupCommands,
                                    accentColor = PythonAmber,
                                    testTagPrefix = "forge_setup"
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                TerminalCodeViewer(tool = tool)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
