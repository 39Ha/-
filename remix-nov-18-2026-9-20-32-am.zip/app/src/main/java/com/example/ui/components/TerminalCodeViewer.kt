package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ToolEntity
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.PythonAmber
import com.example.ui.theme.TerminalCodeBg

fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(context, context.getString(R.string.copy_success), Toast.LENGTH_SHORT).show()
}

fun buildTermuxOneLiner(tool: ToolEntity): String {
    val setup = tool.setupCommands
        .lines()
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .joinToString(" && ")
    val safeSetup = if (setup.isNotEmpty()) "$setup && " else ""
    val delimiter = "PYTERMUX_EOF_942"
    return "${safeSetup}cat << '$delimiter' > ${tool.fileName}\n${tool.sourceCode}\n$delimiter\n${tool.runCommand}"
}

fun shareToolAsText(context: Context, tool: ToolEntity) {
    val shareBody = buildString {
        appendLine("🛠️ ${tool.name}")
        appendLine("👨‍💻 المطور: حسين عليشدهان (Hussein Alishadhan)")
        appendLine("📁 الملف: ${tool.fileName}")
        appendLine()
        appendLine("📥 أوامر التجهيز في Termux:")
        appendLine(tool.setupCommands)
        appendLine()
        appendLine("▶️ أمر التشغيل:")
        appendLine(tool.runCommand)
        appendLine()
        appendLine("💻 الكود البرمجي:")
        appendLine(tool.sourceCode)
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, tool.name)
        putExtra(Intent.EXTRA_TEXT, shareBody)
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة الأداة"))
}

@Composable
fun TerminalCommandBox(
    title: String,
    command: String,
    accentColor: Color = EmeraldNeon,
    testTagPrefix: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = TerminalCodeBg,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = accentColor
                    )
                }
                IconButton(
                    onClick = { copyToClipboard(context, title, command) },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("${testTagPrefix}_copy_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = context.getString(R.string.cd_copy),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.padding(top = 4.dp))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                SelectionContainer {
                    Text(
                        text = command,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        color = Color(0xFFE2E8F0),
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun TerminalCodeViewer(
    tool: ToolEntity,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lines = tool.sourceCode.lines()

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = TerminalCodeBg,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column {
            // Window Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFF5F56))
                    )
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(PythonAmber)
                    )
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(EmeraldNeon)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = tool.fileName,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = CyberCyan
                    )
                }

                IconButton(
                    onClick = { copyToClipboard(context, tool.fileName, tool.sourceCode) },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("copy_source_code_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = context.getString(R.string.cd_copy),
                        tint = EmeraldNeon,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Code body always rendered LTR
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                SelectionContainer {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 420.dp)
                            .horizontalScroll(rememberScrollState())
                            .padding(14.dp)
                    ) {
                        lines.forEachIndexed { index, line ->
                            Row(
                                modifier = Modifier.padding(vertical = 1.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = "${index + 1}".padStart(3, ' '),
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 11.sp,
                                    lineHeight = 19.sp,
                                    color = Color(0xFF475569)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = line,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 12.5.sp,
                                    lineHeight = 19.sp,
                                    color = when {
                                        line.trimStart().startsWith("#") -> Color(0xFF6EE7B7)
                                        line.trimStart().startsWith("def ") ||
                                            line.trimStart().startsWith("import ") ||
                                            line.trimStart().startsWith("from ") -> PythonAmber
                                        else -> Color(0xFFE2E8F0)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // One-liner quick copy footer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                    )
                    .padding(12.dp)
            ) {
                FilledTonalButton(
                    onClick = {
                        copyToClipboard(
                            context,
                            "أمر التشغيل الفوري",
                            buildTermuxOneLiner(tool)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("copy_termux_oneliner_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "نسخ أمر التثبيت والتشغيل المباشر في Termux",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}
