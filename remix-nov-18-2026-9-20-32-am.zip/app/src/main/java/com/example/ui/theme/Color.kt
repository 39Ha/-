package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber-Terminal Dark Studio Palette
val TerminalObsidian = Color(0xFF0A0F14)
val TerminalSurface = Color(0xFF111821)
val TerminalSurfaceElevated = Color(0xFF18222E)
val TerminalSurfaceHighest = Color(0xFF212E3E)
val TerminalCodeBg = Color(0xFF070B0F)

val EmeraldNeon = Color(0xFF10E88A)
val EmeraldDeep = Color(0xFF064E32)
val EmeraldSoft = Color(0xFFA6F7D0)

val PythonAmber = Color(0xFFFFB84D)
val PythonAmberDeep = Color(0xFF4D3208)
val PythonAmberSoft = Color(0xFFFFE1B3)

val CyberCyan = Color(0xFF38BDF8)
val CyberCyanDeep = Color(0xFF0A3950)
val CyberCyanSoft = Color(0xFFBAE6FD)

val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val BorderSubtleDark = Color(0xFF283546)

val ErrorCoral = Color(0xFFFF5C77)
val ErrorContainerDark = Color(0xFF4A1520)

// Clean Light Palette (optional / system fallback)
val LightBg = Color(0xFFF5F7FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8EEF5)
val EmeraldPrimaryLight = Color(0xFF058A52)
val AmberSecondaryLight = Color(0xFFB46900)
val CyanTertiaryLight = Color(0xFF0277BD)
