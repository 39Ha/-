package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ToolEntity
import com.example.data.ToolRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ForgeUiState {
    data object Idle : ForgeUiState
    data object Loading : ForgeUiState
    data class Success(val tool: ToolEntity) : ForgeUiState
    data class Error(val message: String) : ForgeUiState
}

enum class LibraryFilter {
    ALL, CUSTOM_ONLY, FAVORITES_ONLY
}

class ToolForgeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ToolRepository

    init {
        val db = AppDatabase.getInstance(application)
        repository = ToolRepository(db.toolDao())
        viewModelScope.launch {
            repository.ensurePresetsSeeded()
        }
    }

    val allTools: StateFlow<List<ToolEntity>> = repository.allTools
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _forgeUiState = MutableStateFlow<ForgeUiState>(ForgeUiState.Idle)
    val forgeUiState: StateFlow<ForgeUiState> = _forgeUiState.asStateFlow()

    private val _toolNameInput = MutableStateFlow("")
    val toolNameInput: StateFlow<String> = _toolNameInput.asStateFlow()

    private val _extraNotesInput = MutableStateFlow("")
    val extraNotesInput: StateFlow<String> = _extraNotesInput.asStateFlow()

    private val _selectedEnvironment = MutableStateFlow("Python + Termux")
    val selectedEnvironment: StateFlow<String> = _selectedEnvironment.asStateFlow()

    private val _selectedTier = MutableStateFlow("تجهيز وتنزيل")
    val selectedTier: StateFlow<String> = _selectedTier.asStateFlow()

    private val _presetSearchQuery = MutableStateFlow("")
    val presetSearchQuery: StateFlow<String> = _presetSearchQuery.asStateFlow()

    private val _selectedPresetCategory = MutableStateFlow("الكل")
    val selectedPresetCategory: StateFlow<String> = _selectedPresetCategory.asStateFlow()

    private val _libraryFilter = MutableStateFlow(LibraryFilter.ALL)
    val libraryFilter: StateFlow<LibraryFilter> = _libraryFilter.asStateFlow()

    val filteredPresets: StateFlow<List<ToolEntity>> = combine(
        allTools,
        presetSearchQuery,
        selectedPresetCategory
    ) { tools, query, category ->
        tools.filter { it.isPreset }
            .filter { tool ->
                category == "الكل" || tool.category == category
            }
            .filter { tool ->
                if (query.isBlank()) true
                else tool.name.contains(query, ignoreCase = true) ||
                    tool.summary.contains(query, ignoreCase = true) ||
                    tool.fileName.contains(query, ignoreCase = true)
            }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val libraryTools: StateFlow<List<ToolEntity>> = combine(
        allTools,
        libraryFilter
    ) { tools, filter ->
        when (filter) {
            LibraryFilter.ALL -> tools.filter { !it.isPreset || it.isFavorite }
            LibraryFilter.CUSTOM_ONLY -> tools.filter { !it.isPreset }
            LibraryFilter.FAVORITES_ONLY -> tools.filter { it.isFavorite }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun observeToolById(toolId: Long): Flow<ToolEntity?> = repository.observeToolById(toolId)

    fun updateToolNameInput(value: String) {
        _toolNameInput.value = value
    }

    fun updateExtraNotesInput(value: String) {
        _extraNotesInput.value = value
    }

    fun selectEnvironment(env: String) {
        _selectedEnvironment.value = env
    }

    fun selectTier(tier: String) {
        _selectedTier.value = tier
    }

    fun updatePresetSearchQuery(query: String) {
        _presetSearchQuery.value = query
    }

    fun selectPresetCategory(category: String) {
        _selectedPresetCategory.value = category
    }

    fun selectLibraryFilter(filter: LibraryFilter) {
        _libraryFilter.value = filter
    }

    fun prefillFromPreset(tool: ToolEntity) {
        _toolNameInput.value = "تطوير وتحسين: ${tool.name}"
        _selectedEnvironment.value = tool.environment
        _selectedTier.value = tool.tier
        _extraNotesInput.value = "بناءً على الأداة ${tool.fileName}، أضف ميزات إضافية وتنسيقاً أفضل."
        _forgeUiState.value = ForgeUiState.Idle
    }

    fun clearForgeState() {
        _forgeUiState.value = ForgeUiState.Idle
    }

    fun forgeTool() {
        val name = _toolNameInput.value.trim()
        if (name.isEmpty()) {
            _forgeUiState.value = ForgeUiState.Error("اكتب اسم الأداة أو وصفها أولاً قبل البدء.")
            return
        }

        viewModelScope.launch {
            _forgeUiState.value = ForgeUiState.Loading
            val result = repository.generateCustomTool(
                requestedName = name,
                environment = _selectedEnvironment.value,
                tier = _selectedTier.value,
                extraNotes = _extraNotesInput.value.trim()
            )
            result.fold(
                onSuccess = { createdTool ->
                    _forgeUiState.value = ForgeUiState.Success(createdTool)
                },
                onFailure = { error ->
                    _forgeUiState.value = ForgeUiState.Error(
                        error.message ?: "تعذر إنشاء الأداة حالياً."
                    )
                }
            )
        }
    }

    fun toggleFavorite(tool: ToolEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(tool.id, !tool.isFavorite)
        }
    }

    fun deleteTool(tool: ToolEntity) {
        viewModelScope.launch {
            repository.deleteTool(tool.id)
            val current = _forgeUiState.value
            if (current is ForgeUiState.Success && current.tool.id == tool.id) {
                _forgeUiState.value = ForgeUiState.Idle
            }
        }
    }
}
